const props = {
    height: {
        type: Number,
    },
    list: {
        type: Array,
        value: [],
        required: true,
    },
};
export default props;
