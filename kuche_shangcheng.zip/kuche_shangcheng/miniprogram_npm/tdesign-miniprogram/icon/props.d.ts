import { TdIconProps } from './type';
declare const props: TdIconProps;
export default props;
