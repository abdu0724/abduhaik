import { TdStepItemProps } from './type';
declare const props: TdStepItemProps;
export default props;
