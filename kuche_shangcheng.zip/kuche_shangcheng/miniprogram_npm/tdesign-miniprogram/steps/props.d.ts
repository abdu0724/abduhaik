import { TdStepsProps } from './type';
declare const props: TdStepsProps;
export default props;
