import { TdDividerProps } from './type';
declare const props: TdDividerProps;
export default props;
