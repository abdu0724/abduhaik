export declare function canIUseFormFieldButton(): boolean;
