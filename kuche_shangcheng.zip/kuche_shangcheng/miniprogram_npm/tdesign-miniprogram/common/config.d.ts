declare const _default: {
    prefix: string;
};
export default _default;
