import { TdSliderProps } from './type';
declare const props: TdSliderProps;
export default props;
