import updateManager from './common/updateManager';

App({
  onLaunch: function () {},
  onShow: function () {
    updateManager();
  },

  wx_login() {
    var that = this;
    wx.showLoading({
      title: '登录中',
    })
    wx.login({
      success: (res) => {
        console.log(res.code);
        wx.request({
          url: that.globalData.servername + "wx_api/login.php?code=" + res.code,
          success: function (res) {
            app.globalData.userInfo = res.data
            wx.hideLoading();
          },
          fail: function (res) {
            console.log(res.data);
          }
        })
      },
    })
  },
  globalData: {
    servername: "https://saharsoft.com/mini_program/",
    userInfo: {},
    systeminfo: {}
  }
});